(function () {
  const { PRESETS, buildLines } = window.AsciiCore;
  const { toMono, buildPrintJob, textJob } = window.EscPos;
  const $ = (s) => document.querySelector(s);
  const NATIVE = typeof window.AndroidPrinter !== "undefined";
  const notify = (m) => (NATIVE ? window.AndroidPrinter.toast(String(m)) : alert(m));

  const REF_W = 800; // reference width (px) used to derive column count
  const MAX_COLS = 600;
  const MAX_CANVAS = 8000;
  const FONT_STACK = '"Courier New", Courier, "DejaVu Sans Mono", monospace';

  const DEFAULTS = {
    preset: "dense", custom: "@%#*+=-:. ", brightness: 0, contrast: 0,
    scale: 1, fontSize: 8, density: 1, invert: false,
    paper: "384", printCols: 48, speed: "normal", dither: true, feed: 3,
  };
  let state = Object.assign({}, DEFAULTS, loadSaved());
  let img = null; // HTMLImageElement
  let result = null; // { lines, canvas info }

  function loadSaved() {
    try { return JSON.parse(localStorage.getItem("ascii-printer") || "{}"); } catch (e) { return {}; }
  }
  function save() {
    try { localStorage.setItem("ascii-printer", JSON.stringify(state)); } catch (e) {}
  }

  // ---------- UI wiring ----------
  const presetEl = $("#preset");
  Object.keys(PRESETS).forEach((k) => {
    const o = document.createElement("option");
    o.value = k; o.textContent = PRESETS[k].label;
    presetEl.appendChild(o);
  });

  const sliders = ["brightness", "contrast", "scale", "fontSize", "density"];
  const fmt = { brightness: (v) => String(v), contrast: (v) => String(v), scale: (v) => v.toFixed(2), fontSize: (v) => String(v), density: (v) => v.toFixed(2) };

  function syncUI() {
    presetEl.value = state.preset;
    $("#custom").hidden = state.preset !== "custom";
    $("#custom").value = state.custom;
    sliders.forEach((k) => { $("#" + k).value = state[k]; $("#" + k + "V").textContent = fmt[k](Number(state[k])); });
    $("#invert").checked = !!state.invert;
    $("#paper").value = state.paper;
    $("#speed").value = state.speed;
    $("#feed").value = state.feed;
    $("#printCols").value = String(state.printCols);
  }

  presetEl.addEventListener("change", () => { state.preset = presetEl.value; $("#custom").hidden = state.preset !== "custom"; changed(); });
  $("#custom").addEventListener("input", (e) => { state.custom = e.target.value; changed(); });
  sliders.forEach((k) => $("#" + k).addEventListener("input", (e) => {
    state[k] = parseFloat(e.target.value);
    $("#" + k + "V").textContent = fmt[k](state[k]);
    changed();
  }));
  $("#invert").addEventListener("change", (e) => { state.invert = e.target.checked; changed(); });
  $("#paper").addEventListener("change", (e) => { state.paper = e.target.value; save(); });
  $("#speed").addEventListener("change", (e) => { state.speed = e.target.value; save(); });
  $("#feed").addEventListener("change", (e) => { state.feed = Math.max(0, Math.min(10, parseInt(e.target.value, 10) || 0)); save(); });
  $("#printCols").addEventListener("change", (e) => { state.printCols = parseInt(e.target.value, 10) || 48; save(); });
  $("#reset").addEventListener("click", () => { state = Object.assign({}, DEFAULTS); syncUI(); changed(); });

  $("#file").addEventListener("change", (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    const im = new Image();
    im.onload = () => { img = im; URL.revokeObjectURL(url); changed(); };
    im.onerror = () => { notify("Could not read that image."); URL.revokeObjectURL(url); };
    im.src = url;
  });

  let raf = 0;
  function changed() {
    save();
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(render);
  }

  // ---------- Rendering ----------
  function currentRamp() {
    return state.preset === "custom" ? state.custom : PRESETS[state.preset].ramp;
  }

  function render() {
    if (!img) return;
    const cv = $("#out");
    const ctx = cv.getContext("2d");
    const fs = state.fontSize;
    ctx.font = fs + "px " + FONT_STACK;
    const charW = ctx.measureText("M").width || fs * 0.6;
    const lineH = fs * 1.0;

    let cols = Math.round((REF_W / charW) * state.density);
    cols = Math.max(8, Math.min(MAX_COLS, cols));
    const aspect = img.naturalHeight / img.naturalWidth;
    const rows = Math.max(1, Math.round(cols * aspect * (charW / lineH)));

    // sample the image at cols x rows
    const tmp = document.createElement("canvas");
    tmp.width = cols; tmp.height = rows;
    const tctx = tmp.getContext("2d", { willReadFrequently: true });
    tctx.fillStyle = "#fff";
    tctx.fillRect(0, 0, cols, rows);
    tctx.imageSmoothingEnabled = true;
    tctx.imageSmoothingQuality = "high";
    tctx.drawImage(img, 0, 0, cols, rows);
    const data = tctx.getImageData(0, 0, cols, rows).data;

    const lines = buildLines(data, cols, rows, {
      ramp: currentRamp(), brightness: state.brightness, contrast: state.contrast, invert: state.invert,
    });

    let scale = state.scale;
    const w0 = cols * charW, h0 = rows * lineH;
    scale = Math.min(scale, MAX_CANVAS / w0, MAX_CANVAS / h0);
    cv.width = Math.max(1, Math.round(w0 * scale));
    cv.height = Math.max(1, Math.round(h0 * scale));
    const c2 = cv.getContext("2d");
    c2.fillStyle = state.invert ? "#000" : "#fff";
    c2.fillRect(0, 0, cv.width, cv.height);
    c2.setTransform(scale, 0, 0, scale, 0, 0);
    c2.font = fs + "px " + FONT_STACK;
    c2.textBaseline = "top";
    c2.fillStyle = state.invert ? "#fff" : "#000";
    for (let y = 0; y < lines.length; y++) {
      const chars = Array.from(lines[y]);
      for (let x = 0; x < chars.length; x++) if (chars[x] !== " ") c2.fillText(chars[x], x * charW, y * lineH);
    }
    c2.setTransform(1, 0, 0, 1, 0, 0);

    result = { lines, cols, rows };
    $("#previewBox").classList.add("has");
    $("#info").textContent = cols + " characters per row × " + rows + " rows · " + cv.width + "×" + cv.height + " px";
  }

  // ---------- Downloads ----------
  function download(blob, name) {
    if (NATIVE) {
      const fr = new FileReader();
      fr.onload = () => {
        const s = String(fr.result);
        notify(window.AndroidPrinter.saveFile(name, blob.type || "application/octet-stream", s.slice(s.indexOf(",") + 1)));
      };
      fr.readAsDataURL(blob);
      return;
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function needImage() { if (!result) { notify("Choose an image first."); return false; } return true; }

  $("#dlPng").addEventListener("click", () => { if (needImage()) $("#out").toBlob((b) => download(b, "ascii.png"), "image/png"); });
  $("#dlTxt").addEventListener("click", () => { if (needImage()) download(new Blob([result.lines.join("\n")], { type: "text/plain" }), "ascii.txt"); });
  $("#dlHtml").addEventListener("click", () => {
    if (!needImage()) return;
    const esc = result.lines.join("\n").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const bg = state.invert ? "#000" : "#fff", fg = state.invert ? "#fff" : "#000";
    const html = '<!doctype html><html><head><meta charset="utf-8"><title>ASCII</title></head><body style="margin:0;background:' + bg + '">' +
      '<pre style="margin:0;padding:8px;color:' + fg + ";font:" + state.fontSize + "px/1 " + FONT_STACK + ';">' + esc + "</pre></body></html>";
    download(new Blob([html], { type: "text/html" }), "ascii.html");
  });

  // ---------- Bluetooth printing ----------
  const SPEEDS = { fast: { chunk: 180, delay: 8 }, normal: { chunk: 100, delay: 15 }, safe: { chunk: 20, delay: 25 } };
  const KNOWN_SERVICES = [
    "000018f0-0000-1000-8000-00805f9b34fb",
    "0000ff00-0000-1000-8000-00805f9b34fb",
    "0000ffe0-0000-1000-8000-00805f9b34fb",
    "0000fee7-0000-1000-8000-00805f9b34fb",
    "0000ae30-0000-1000-8000-00805f9b34fb",
    "49535343-fe7d-4ae5-8fa9-9fafd205e455",
    "e7810a71-73ae-499d-8c15-faa9aef0c3f2",
  ];
  let device = null, characteristic = null;
  const status = (t) => ($("#btStatus").textContent = t);
  const setBtn = (connected) => {
    $("#btnPrint").disabled = !connected;
    $("#btnTest").disabled = !connected;
    $("#btnDisconnect").disabled = !connected;
    $("#btnConnect").disabled = false;
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  if (!navigator.bluetooth) {
    status("Web Bluetooth isn't available in this browser. Use Chrome or Edge (Android/desktop) over HTTPS.");
    $("#btnConnect").disabled = true;
  }

  async function connect() {
    try {
      status("Choose your printer…");
      device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: KNOWN_SERVICES });
      device.addEventListener("gattserverdisconnected", () => { characteristic = null; setBtn(false); status("Disconnected."); });
      status("Connecting to " + (device.name || "printer") + "…");
      const server = await device.gatt.connect();
      const services = await server.getPrimaryServices();
      let found = null;
      for (const s of services) {
        const chars = await s.getCharacteristics();
        for (const c of chars) {
          if (c.properties.write || c.properties.writeWithoutResponse) { found = c; break; }
        }
        if (found) break;
      }
      if (!found) throw new Error("No writable characteristic found on this device.");
      characteristic = found;
      setBtn(true);
      status("Connected to " + (device.name || "printer") + ".");
    } catch (err) {
      if (err && err.name === "NotFoundError") status("No printer selected.");
      else status("Connection failed: " + (err && err.message ? err.message : err));
      setBtn(false);
    }
  }

  async function sendBytes(bytes) {
    if (!characteristic) throw new Error("Printer not connected.");
    let { chunk, delay } = SPEEDS[state.speed] || SPEEDS.normal;
    let i = 0;
    while (i < bytes.length) {
      const slice = bytes.slice(i, i + chunk);
      try {
        if (characteristic.properties.writeWithoutResponse && characteristic.writeValueWithoutResponse) await characteristic.writeValueWithoutResponse(slice);
        else await characteristic.writeValue(slice);
      } catch (e) {
        if (chunk > 20) { chunk = 20; delay = 25; continue; } // fall back to tiny packets and retry
        throw e;
      }
      i += slice.length;
      status("Sending… " + Math.round((i / bytes.length) * 100) + "%");
      await sleep(delay);
    }
  }

  // Print render: draw the ASCII on an exact printer-width grid, one character per fixed cell,
  // so every glyph lands in its own place (no scaling, no font-width surprises).
  function makeJob() {
    const dots = parseInt(state.paper, 10);
    const cols = Math.max(16, Math.min(Math.floor(dots / 4), state.printCols || 48));
    const cellW = Math.floor(dots / cols);
    const cellH = cellW * 2;
    const aspect = img.naturalHeight / img.naturalWidth;
    const rows = Math.max(1, Math.round((cols * aspect * cellW) / cellH));

    const tmp = document.createElement("canvas");
    tmp.width = cols; tmp.height = rows;
    const tctx = tmp.getContext("2d", { willReadFrequently: true });
    tctx.fillStyle = "#fff"; tctx.fillRect(0, 0, cols, rows);
    tctx.imageSmoothingEnabled = true; tctx.imageSmoothingQuality = "high";
    tctx.drawImage(img, 0, 0, cols, rows);
    const lines = buildLines(tctx.getImageData(0, 0, cols, rows).data, cols, rows, {
      ramp: currentRamp(), brightness: state.brightness, contrast: state.contrast, invert: state.invert,
    });

    const h = rows * cellH;
    const c = document.createElement("canvas");
    c.width = dots; c.height = h;
    const x = c.getContext("2d", { willReadFrequently: true });
    x.fillStyle = state.invert ? "#000" : "#fff"; x.fillRect(0, 0, dots, h);
    // pick a font size whose glyph width equals the cell width
    x.font = "100px " + FONT_STACK;
    const ratio = (x.measureText("M").width || 60) / 100;
    const fontPx = Math.max(4, Math.min(cellH * 0.95, cellW / ratio));
    x.font = "bold " + fontPx + "px " + FONT_STACK;
    x.textAlign = "center"; x.textBaseline = "middle";
    x.fillStyle = state.invert ? "#fff" : "#000";
    const off = Math.floor((dots - cols * cellW) / 2);
    for (let r = 0; r < rows; r++) {
      const chars = Array.from(lines[r]);
      for (let k = 0; k < chars.length; k++) {
        if (chars[k] !== " ") x.fillText(chars[k], off + k * cellW + cellW / 2, r * cellH + cellH / 2);
      }
    }
    const px = x.getImageData(0, 0, dots, h).data;
    const mono = toMono(px, dots, h, { dither: false, threshold: 185 });
    return { bytes: buildPrintJob(mono, dots, h, { bandRows: 64, feedLines: state.feed }), dots, h, canvas: c, mono };
  }

  function b64(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  // Classic-Bluetooth printers (most "bill printers"): hand the ESC/POS data to the RawBT Android app.
  function printViaRawBT() {
    if (!needImage()) return;
    const job = makeJob();
    const data = b64(job.bytes);
    $("#rawStatus").textContent = "Opening RawBT… (" + Math.round(data.length / 1024) + " KB)";
    window.location.href = "intent:base64," + data + "#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;end;";
  }

  // Fallback: share the 1-bit receipt image (RawBT, or any print app, can print it).
  async function shareImage() {
    if (!needImage()) return;
    const job = makeJob();
    const out = document.createElement("canvas");
    out.width = job.dots; out.height = job.h;
    const o = out.getContext("2d");
    const id = o.createImageData(job.dots, job.h);
    for (let i = 0; i < job.mono.length; i++) { const v = job.mono[i] ? 0 : 255; id.data[i * 4] = id.data[i * 4 + 1] = id.data[i * 4 + 2] = v; id.data[i * 4 + 3] = 255; }
    o.putImageData(id, 0, 0);
    out.toBlob(async (blob) => {
      const file = new File([blob], "receipt.png", { type: "image/png" });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        try { await navigator.share({ files: [file], title: "ASCII receipt" }); } catch (e) {}
      } else download(blob, "receipt.png");
    }, "image/png");
  }

  async function printImage() {
    if (!needImage()) return;
    $("#btnPrint").disabled = true;
    try {
      const { bytes: job, dots, h } = makeJob();
      await sendBytes(job);
      status("Done. Printed " + dots + "×" + h + " dots.");
    } catch (err) {
      status("Print failed: " + (err && err.message ? err.message : err));
    } finally {
      $("#btnPrint").disabled = !characteristic;
    }
  }

  $("#btnRawbt").addEventListener("click", printViaRawBT);
  $("#btnShare").addEventListener("click", shareImage);
  $("#btnConnect").addEventListener("click", connect);
  $("#btnPrint").addEventListener("click", printImage);
  $("#btnTest").addEventListener("click", async () => {
    try { await sendBytes(textJob("ASCII Printer test\nHello 58mm!\n", state.feed)); status("Test sent."); }
    catch (e) { status("Test failed: " + e.message); }
  });
  $("#btnDisconnect").addEventListener("click", () => { if (device && device.gatt.connected) device.gatt.disconnect(); });

  // ---------- Native Android app: classic Bluetooth (SPP) printing ----------
  if (NATIVE) {
    document.documentElement.classList.add("native");
    $("#nativeSection").hidden = false;
    const sel = $("#nPrinter"), nst = $("#nStatus");
    const NS = { fast: { chunk: 512, delay: 5 }, normal: { chunk: 256, delay: 15 }, safe: { chunk: 64, delay: 30 } };
    let busy = false;
    const setBusy = (b) => { busy = b; $("#nPrint").disabled = b; $("#nTest").disabled = b; };

    function loadPrinters() {
      let r;
      try { r = JSON.parse(window.AndroidPrinter.listPrinters()); } catch (e) { r = { error: "Could not read paired printers." }; }
      sel.innerHTML = "";
      if (r.error) { nst.textContent = r.error; return; }
      if (!r.devices.length) { nst.textContent = "No paired devices. Pair the printer in Android Bluetooth settings, then tap Refresh."; return; }
      r.devices.forEach((d) => {
        const o = document.createElement("option");
        o.value = d.address; o.textContent = d.name + "  (" + d.address + ")";
        sel.appendChild(o);
      });
      try { const last = localStorage.getItem("ascii-printer-dev"); if (last) sel.value = last; } catch (e) {}
      nst.textContent = "Choose your printer, then tap Print.";
    }
    sel.addEventListener("change", () => { try { localStorage.setItem("ascii-printer-dev", sel.value); } catch (e) {} });

    window.onNativePermission = loadPrinters;
    window.onNativeProgress = (p) => { nst.textContent = "Sending… " + p + "%"; };
    window.onNativePrint = (ok, msg) => { setBusy(false); nst.textContent = ok ? "Done." : "Print failed: " + msg; };

    function nativeSend(bytes) {
      if (busy) return;
      if (!sel.value) { nst.textContent = "Choose a printer first."; return; }
      setBusy(true);
      nst.textContent = "Connecting…";
      const sp = NS[state.speed] || NS.normal;
      window.AndroidPrinter.print(sel.value, b64(bytes), sp.chunk, sp.delay);
    }
    $("#nRefresh").addEventListener("click", loadPrinters);
    $("#nPrint").addEventListener("click", () => { if (needImage()) nativeSend(makeJob().bytes); });
    $("#nTest").addEventListener("click", () => nativeSend(textJob("ASCII Printer test\nHello 58mm!\n", state.feed)));
    loadPrinters();
  }

  syncUI();
})();
