/* ESC/POS helpers for 58mm thermal printers (pure functions, no DOM). */
(function (root) {
  /**
   * Convert RGBA pixels to 1-bit (1 = black dot).
   * opts: { threshold (0-255), dither (bool) }
   * Returns Uint8Array of w*h values (0 or 1).
   */
  function toMono(rgba, w, h, opts) {
    const threshold = opts && opts.threshold != null ? opts.threshold : 140;
    const dither = !opts || opts.dither !== false;
    const gray = new Float32Array(w * h);
    for (let i = 0; i < w * h; i++) {
      const a = rgba[i * 4 + 3] / 255;
      const r = rgba[i * 4] * a + 255 * (1 - a);
      const g = rgba[i * 4 + 1] * a + 255 * (1 - a);
      const b = rgba[i * 4 + 2] * a + 255 * (1 - a);
      gray[i] = 0.299 * r + 0.587 * g + 0.114 * b;
    }
    const out = new Uint8Array(w * h);
    if (dither) {
      // Floyd–Steinberg
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = y * w + x;
          const old = gray[i];
          const nw = old < 128 ? 0 : 255;
          out[i] = nw === 0 ? 1 : 0;
          const err = old - nw;
          if (x + 1 < w) gray[i + 1] += (err * 7) / 16;
          if (y + 1 < h) {
            if (x > 0) gray[i + w - 1] += (err * 3) / 16;
            gray[i + w] += (err * 5) / 16;
            if (x + 1 < w) gray[i + w + 1] += (err * 1) / 16;
          }
        }
      }
    } else {
      for (let i = 0; i < w * h; i++) out[i] = gray[i] < threshold ? 1 : 0;
    }
    return out;
  }

  /**
   * Build ESC/POS bytes for a mono bitmap.
   * w must be a multiple of 8. Image is sent in bands so small printer buffers cope.
   * opts: { bandRows (default 64), feedLines (default 3) }
   */
  function buildPrintJob(mono, w, h, opts) {
    if (w % 8 !== 0) throw new Error("Width must be a multiple of 8");
    const bandRows = (opts && opts.bandRows) || 64;
    const feed = opts && opts.feedLines != null ? opts.feedLines : 3;
    const wb = w / 8;
    const parts = [new Uint8Array([0x1b, 0x40])]; // ESC @ init
    for (let y0 = 0; y0 < h; y0 += bandRows) {
      const rows = Math.min(bandRows, h - y0);
      const buf = new Uint8Array(8 + wb * rows);
      buf.set([0x1d, 0x76, 0x30, 0x00, wb & 0xff, wb >> 8, rows & 0xff, rows >> 8], 0); // GS v 0
      let p = 8;
      for (let y = 0; y < rows; y++) {
        for (let xb = 0; xb < wb; xb++) {
          let byte = 0;
          for (let bit = 0; bit < 8; bit++) {
            if (mono[(y0 + y) * w + xb * 8 + bit]) byte |= 0x80 >> bit;
          }
          buf[p++] = byte;
        }
      }
      parts.push(buf);
    }
    parts.push(new Uint8Array([0x1b, 0x64, feed & 0xff])); // ESC d n  feed
    let total = 0;
    parts.forEach((a) => (total += a.length));
    const out = new Uint8Array(total);
    let o = 0;
    parts.forEach((a) => {
      out.set(a, o);
      o += a.length;
    });
    return out;
  }

  function textJob(str, feed) {
    const enc = new TextEncoder().encode(str);
    const out = new Uint8Array(2 + enc.length + 3);
    out.set([0x1b, 0x40], 0);
    out.set(enc, 2);
    out.set([0x1b, 0x64, feed == null ? 3 : feed], 2 + enc.length);
    return out;
  }

  const api = { toMono, buildPrintJob, textJob };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.EscPos = api;
})(typeof window !== "undefined" ? window : globalThis);
