/* Core image -> ASCII conversion (pure functions, no DOM). */
(function (root) {
  // Ramps are ordered DARK pixel -> LIGHT pixel (densest glyph first, space last).
  const PRESETS = {
    dense: {
      label: "Dense",
      ramp: "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/|()1{}[]?-_+~<>i!lI;:,\"^`'. ",
    },
    standard: { label: "Standard", ramp: "@%#*+=-:. " },
    simple: { label: "Simple", ramp: "#+-. " },
    minimal: { label: "Minimal", ramp: "@. " },
    blocks: { label: "Blocks", ramp: "█▓▒░ " },
    binary: { label: "Binary", ramp: "10 " },
    custom: { label: "Custom…", ramp: "@%#*+=-:. " },
  };

  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  /**
   * data: RGBA Uint8ClampedArray (w*h*4)
   * opts: { ramp, brightness (-100..100), contrast (-100..100), invert }
   * returns array of strings (one per row)
   */
  function buildLines(data, w, h, opts) {
    const ramp = Array.from(opts.ramp && opts.ramp.length ? opts.ramp : "@. ");
    const n = ramp.length;
    const b = (opts.brightness || 0) * 2.55;
    const c = clamp(opts.contrast || 0, -100, 100) * 2.55;
    const factor = (259 * (c + 255)) / (255 * (259 - c));
    const lines = [];
    for (let y = 0; y < h; y++) {
      let line = "";
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const a = data[i + 3] / 255;
        // transparent pixels count as white paper
        const r = data[i] * a + 255 * (1 - a);
        const g = data[i + 1] * a + 255 * (1 - a);
        const bl = data[i + 2] * a + 255 * (1 - a);
        let lum = 0.2126 * r + 0.7152 * g + 0.0722 * bl;
        lum = factor * (lum - 128) + 128 + b;
        lum = clamp(lum, 0, 255) / 255;
        if (opts.invert) lum = 1 - lum;
        line += ramp[Math.round(lum * (n - 1))];
      }
      lines.push(line);
    }
    return lines;
  }

  const api = { PRESETS, buildLines, clamp };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.AsciiCore = api;
})(typeof window !== "undefined" ? window : globalThis);
