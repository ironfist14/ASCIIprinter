# ASCII Printer (Android APK)

Image → ASCII art with live settings, downloads (PNG/TXT/HTML), and printing to a **classic-Bluetooth 58mm thermal bill printer**.

- `web/` – the app UI (HTML/JS). Bundled inside the APK.
- `app/` – small Android wrapper (WebView + Bluetooth SPP bridge).
- `.github/workflows/build-apk.yml` – builds the APK in the cloud.

## Get the APK
1. Push everything in this folder to a GitHub repo (branch `main`).
2. Open the repo's **Actions** tab. The "Build APK" run starts automatically (about 3–5 min).
3. When it's green, open the repo's **Releases** (right side of the repo page). Download `app-debug.apk` from the newest release.
4. Open the file on your phone and allow "Install unknown apps" when asked.

## Use
1. Pair the printer in Android Settings → Bluetooth.
2. Open ASCII Printer, allow the Bluetooth permission, pick the printer, choose an image, tap **Print**.
