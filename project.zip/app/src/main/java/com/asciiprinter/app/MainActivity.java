package com.asciiprinter.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 11;
    private static final int REQ_PERM = 12;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private BluetoothSocket socket;
    private String socketAddress;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidPrinter");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        askPermissionIfNeeded();
    }

    private boolean hasBtPermission() {
        if (Build.VERSION.SDK_INT < 31) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermissionIfNeeded() {
        if (!hasBtPermission()) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERM) js("window.onNativePermission && window.onNativePermission()");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && filePathCallback != null) {
            filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closeQuiet();
        io.shutdownNow();
        super.onDestroy();
    }

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(code, null);
            }
        });
    }

    private void closeQuiet() {
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {
        }
        socket = null;
        socketAddress = null;
    }

    private void ensureConnected(String address) throws IOException {
        if (socket != null && address.equals(socketAddress) && socket.isConnected()) return;
        closeQuiet();
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || !adapter.isEnabled()) throw new IOException("Bluetooth is off");
        BluetoothDevice dev = adapter.getRemoteDevice(address);
        BluetoothSocket sock = dev.createRfcommSocketToServiceRecord(SPP);
        try {
            sock.connect();
        } catch (IOException first) {
            // Fallback used by many cheap printers
            try {
                sock.close();
            } catch (Exception ignored) {
            }
            try {
                sock = (BluetoothSocket) dev.getClass().getMethod("createRfcommSocket", int.class).invoke(dev, 1);
                sock.connect();
            } catch (Exception second) {
                throw new IOException("Could not connect. Is the printer on, in range and not used by another app?");
            }
        }
        socket = sock;
        socketAddress = address;
    }

    private void writeAll(String address, byte[] data, int chunk, int delay) throws Exception {
        ensureConnected(address);
        OutputStream os = socket.getOutputStream();
        int i = 0;
        int lastPct = -1;
        while (i < data.length) {
            int n = Math.min(chunk, data.length - i);
            os.write(data, i, n);
            os.flush();
            i += n;
            int pct = (int) (i * 100L / data.length);
            if (pct != lastPct) {
                lastPct = pct;
                js("window.onNativeProgress && window.onNativeProgress(" + pct + ")");
            }
            if (delay > 0) Thread.sleep(delay);
        }
        Thread.sleep(300); // let the printer drain its buffer before any disconnect
    }

    private class Bridge {
        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public String listPrinters() {
            try {
                BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                JSONObject res = new JSONObject();
                if (ad == null) return res.put("error", "This device has no Bluetooth").toString();
                if (!hasBtPermission()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            askPermissionIfNeeded();
                        }
                    });
                    return res.put("error", "Allow the Bluetooth permission, then tap Refresh.").toString();
                }
                if (!ad.isEnabled()) return res.put("error", "Turn Bluetooth on, then tap Refresh.").toString();
                JSONArray arr = new JSONArray();
                for (BluetoothDevice d : ad.getBondedDevices()) {
                    JSONObject o = new JSONObject();
                    String name = d.getName();
                    o.put("name", name == null ? d.getAddress() : name);
                    o.put("address", d.getAddress());
                    arr.put(o);
                }
                res.put("devices", arr);
                return res.toString();
            } catch (Exception e) {
                return "{\"error\":" + JSONObject.quote(String.valueOf(e.getMessage())) + "}";
            }
        }

        @JavascriptInterface
        public void print(final String address, final String b64, final int chunk, final int delay) {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    String err = null;
                    try {
                        byte[] data = Base64.decode(b64, Base64.DEFAULT);
                        try {
                            writeAll(address, data, chunk, delay);
                        } catch (Exception firstTry) {
                            closeQuiet(); // stale connection: reconnect once and resend
                            writeAll(address, data, chunk, delay);
                        }
                    } catch (Exception e) {
                        closeQuiet();
                        err = e.getMessage() == null ? e.toString() : e.getMessage();
                    }
                    if (err == null) js("window.onNativePrint && window.onNativePrint(true,'')");
                    else js("window.onNativePrint && window.onNativePrint(false," + JSONObject.quote(err) + ")");
                }
            });
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "Could not save file";
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    try {
                        os.write(data);
                    } finally {
                        os.close();
                    }
                    return "Saved to Downloads: " + name;
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    File f = new File(dir, name);
                    FileOutputStream os = new FileOutputStream(f);
                    try {
                        os.write(data);
                    } finally {
                        os.close();
                    }
                    return "Saved: " + f.getAbsolutePath();
                }
            } catch (Exception e) {
                return "Save failed: " + e.getMessage();
            }
        }
    }
}
